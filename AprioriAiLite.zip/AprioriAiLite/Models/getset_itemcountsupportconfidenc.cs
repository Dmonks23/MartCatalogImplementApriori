﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AprioriAiLite.Models
{
    class getset_itemcountsupportconfidenc
    {
        public string item { get; set; }
        public int count { get; set; }
        public double support { get; set; }
        public double confidents { get; set; }
        public double supxconf { get; set; }

    }
}
