﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AprioriAiLite.Controlerss
{
    class ctrl_MainWindows
    {
        static MainWindow _mw;
        public ctrl_MainWindows()
        {

        }

        public ctrl_MainWindows(MainWindow mw)
        {
            _mw = mw;
        }
    }
}
